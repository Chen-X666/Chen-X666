import torch

class HiddenStatusHookManager:
    """
    用于自动注册 / 管理 / 清理 forward hook。
    包含自动去重、防止重复注册、自动清空缓存。
    """

    def __init__(self, model):
        self.model = model
        self.handles = []     # 保存hook句柄，便于remove
        self.attn_outputs = []  # 每层 self-attn 输出
        self.mlp_outputs = []   # 每层 MLP 输出
        self.hooks_registered = False

    def _attn_hook(self, module, input, output):
        attn_out = output[0]  # (attn_output, attn_weights, past_key_value)
        self.attn_outputs.append(attn_out.detach().cpu())

    def _mlp_hook(self, module, input, output):
        self.mlp_outputs.append(output.detach().cpu())

    def register_hooks(self):
        """注册 hook（若已注册则自动跳过）"""
        if self.hooks_registered:
            print("[HookManager] Hooks already registered. Skipping.")
            return

        print("[HookManager] Registering forward hooks...")
        for idx, layer in enumerate(self.model.model.layers):
            h1 = layer.self_attn.register_forward_hook(self._attn_hook)
            h2 = layer.mlp.register_forward_hook(self._mlp_hook)
            self.handles.extend([h1, h2])

        self.hooks_registered = True
        print(f"[HookManager] ✅ Registered {len(self.handles)} hooks ({len(self.model.model.layers)} layers).")

    def clear_cache(self):
        """在每次前向推理前清空结果"""
        self.attn_outputs.clear()
        self.mlp_outputs.clear()

    def remove_hooks(self):
        """移除已注册的hook"""
        if not self.hooks_registered:
            print("[HookManager] No hooks to remove.")
            return
        for h in self.handles:
            h.remove()
        self.handles.clear()
        self.hooks_registered = False
        print("[HookManager] ❎ Removed all hooks.")